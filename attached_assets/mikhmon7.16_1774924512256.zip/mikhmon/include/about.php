<?php
/*
 *  Copyright (C) 2018 Laksamadi Guko.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
session_start();
// hide all error
error_reporting(0);
if (!isset($_SESSION["mikhmon"])) {
  header("Location:../admin.php?id=login");
} else {
}
?>
<style>
.iFWrapper {
	position: relative;
	padding-bottom: 56.25%; /* 16:9 */
	padding-top: 25px;
	height: 0;
}
.iFWrapper iframe {
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
  height: 100%;
  border :none;
}
</style>
<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3><i class="fa fa-info-circle"></i> A Propos</h3>
      </div>
      <div class="card-body">
        <h3>MIKHMON V<?= $_SESSION['v']; ?></h3>
<p>
Cette application est dediee aux entrepreneurs hotspot ou que vous soyez.
Esperons plus de succes.
</p>
<p>
  <ul>
    <li>
    Modded : nanoTECH Systems Inc. </br>
    Author : Laksamadi Guko 
      
    </li>
    <li>
      Licence : <a href="https://github.com/laksa19/mikhmonv2/blob/master/LICENSE">GPLv2</a>
    </li>
    <!--li>
      API Class : <a href="https://github.com/BenMenking/routeros-api">routeros-api</a>
    </li-->
  </ul>
</p>
<p>
Thank you to everyone who has supported the development of MIKHMON.
</p>
<div>
    <i>Copyright &copy; <i> 2018 Laksamadi Guko Modifié par nanoTECH Systems Inc. +2250779844356</i></i>
</div>
</div>
</div>
</div>
<div class="col-12">
<div class="card">
  <div class="card-header">
  <h3><i class="fa fa-info-circle"></i> MIKHMON V7.10-7.16.1 ,Modifié par nanoTECH Systems Inc. +2250779844356</h3>
  </div>
  <div class="card-body">
  <!--div class="iFWrapper">
    <iframe src="https://laksa19.github.io/mikhmonv3" ></iframe>
  </div-->
  </div>
</div>
</div>
</div>
