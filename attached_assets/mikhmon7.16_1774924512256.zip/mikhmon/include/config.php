<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<admin','mikhmon>|>qqChrA==');





$data['WA'] = array ('1'=>'WA!v17.mikroot.com:52284','WA@|@HS','WA#|#qqChrA==','WA%WA','WA^wifi.login','WA&FCFA','WA*10','WA(1','WA)','WA=10','WA@!@enable');