<?php
if (!isset($_SESSION["mikhmon"])) {
    header("Location:../admin.php?id=login");
  } else {
        $_SESSION["v"] = "7.10-7.16.1 ,Modifié par nanoTECH Systems Inc. +2250779844356";
    
    }
